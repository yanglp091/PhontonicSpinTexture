function [jx, jy,jz,jnorm] = PNDcurrentBG(rho,phi, para) 
% This function is used to calculate the OAM photon-number density current 
% of a Bessel-Gaussian beam at z=0 plane

% The output is a unit vector [jx,jy,jz] 
% and the norm of the current vector jnorm
% The true current vector is jnorm * [jx,jy,jz]

    lambda0 = para.lambda0; % center wave length
    w0 = para.w0; % waist
    theta_c = para.theta_c;% polar angle of Bessel Gaussian beam
    m = para.m;% index of the helical phase
    p = para.p;
    beta = 2*pi*sin(theta_c)/lambda0;
    
    jnorm = (besselj(p,beta*rho)*exp(-rho.^2/w0^2) ).^2 * abs(m)*lambda0/2/pi./rho;
          
   jx = - sign(m)*sin(phi);  
   jy =sign(m)*cos(phi);
   jz = 0;
end