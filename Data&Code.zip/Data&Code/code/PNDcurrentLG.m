function [jx, jy,jz,jnorm] = PNDcurrentLG(rho,phi, para) 
% This function is used to calculate the photon number density current 
% of a Laguarre-Gaussian beam at z=0 plane

% The output is a unit vector [jx,jy,jz] 
% and the norm of the current vector jnorm
% The true current vector is jnorm * [jx,jy,jz]

    lambda0 = para.lambda0;
    w0 = para.w0; 
    m = para.m;
    p = para.p;
    
    jnorm = ((sqrt(2)*rho/w0)^(abs(m)) * laguerreL(p,abs(m),2*rho^2/w0^2) *exp(-rho^2/w0^2) )^2 * abs(m)*lambda0/2/pi/rho;

    jx = - sign(m)*sin(phi);  
    jy =sign(m)*cos(phi);
    jz = 0;
end