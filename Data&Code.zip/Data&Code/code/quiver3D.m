function qHandle = quiver3D(xArray, yArray, zArray,head_frac,r_stem,r_head,color)

% qHandle = quiver3D(xArray, yArray, zArray,head_frac,r_stem,r_arrow,color) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     Given the xArray= [x1, x2]  ... and 
%     
%     with optional color and head ratios, output a quiver of arrows.
% 
% The inputs are:
%       x,y,z =  vectors of the starting point and the ending point of the
%           arrow, e.g.:  x=[x_start, x_end]; y=[y_start, y_end];z=[z_start,z_end];
%       head_frac = fraction of the arrow length where the head should  start
%       r_stem = radius of the stem
%       r_head = radius of the arrow head (defult = r_stem*2)
%       color =   color of the arrow, can be string of the color name, or RGB vector  (default='blue')
%
% The output is the handle of the surfaceplot graphics object.
% The settings of the plot can changed using: set(h, 'PropertyName', PropertyValue)
%
% example #1:
%        quiver3D([0 0],[0 0],[0 6],.5,3,4,[1 0 .5]);
% example #2:
%        quiver3D([2 0],[5 0],[0 -6],.2,3,5,'r');
% example #3:
%        h = quiver3D([1 0],[0 1],[-2 3],.8,3);
%        set(h,'facecolor',[1 0 0])
%     
%     Author: Li-Ping Yang
%     Created: August 25, 2020
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    qHandle = [];
    
    %% ------------------------------------------------------------Initial verification of input parameters     
    if nargin<3 || nargin>7    
        error('Invalid number of input arguments.  help quiver3D for details');  
    end
    
    numArrows = size(xArray,1);
    if numArrows ~= size(yArray,1)
        error('x and y inputs do not agree.  help quiver3D for details');          
    end

    if numArrows ~= size(zArray,1)
        error('x and z inputs do not agree.  help quiver3D for details');          
    end
    %% ----------------------------------------------------------------------------------Default parameters     
    if nargin<4  
        head_frac = 0.75;
        r_stem = 1;
        r_head = 1.5;        
    end
        

    %% ---------------------------------------------------------------Loop through all arrows and plot in 3D 
    hold on;    
    for i=1:numArrows
        x = xArray(i,:);    y = yArray(i,:);  z =zArray(i,:);
        v = x + y +z; 
        
        if nargin<7   
            idx = mod(i,8)+1; 
            color=colorvalue(idx); 
        end
        
    	if norm(v) > 0
            qHandle(i,:) = arrow3d(x, y, z,head_frac,r_stem,r_head,color);
	    end
    end















