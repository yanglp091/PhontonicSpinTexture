function [lx, ly, lz, lnorm] = OAMtextureBG(rho,phi, para) 
% This function is used to calculate the OAM texure of a Bessel-Gaussian
% beam at z=0 plane

% The OAM density has been normalized by the total photon number |alpha|^2
% The OAM density has been rescaled by the normalization factor hbar*(N_pm)^2

% The output is a unit vector [lx,ly,lz] 
% and the norm of the current vector lnorm
% The true current vector is lnorm * [lx,ly,lz]

    lambda0 = para.lambda0;% center wave length
    w0 = para.w0; % waist
    zR = pi*w0^2/lambda0; % Rayleigh length
    theta_c = para.theta_c;% polar angle of Bessel-Gaussian beam
    m = para.m;% index of the helical phase factor
    p = para.p;
    beta = 2*pi*sin(theta_c)/lambda0;
    
    lz = m*( besselj(p,beta*rho)*exp(-rho^2/w0^2) )^2;
      
    lrho = 0; % The radial component of OAM density in z=0 plane is zero.
          
    lphi = exp(-2*rho^2/w0^2)*(...
         beta*rho^2/zR*besselj(p,beta*rho)*(p/beta/rho*besselj(p,beta*rho)-besselj(p+1,beta*rho))...
         -rho*(besselj(p,beta*rho))^2*(2*pi/lambda0*(1-(sin(theta_c))^2 ) +rho^2/zR/w0^2 -1/zR )...
         ); 
          
     lx = lrho*cos(phi) - lphi * sin(phi);  
     ly = lrho*sin(phi) + lphi * cos(phi);  
      
     lnorm = norm([lx,ly,lz]);
     if lnorm > 0
        lx = lx/lnorm; ly = ly/lnorm; lz = lz/lnorm;
     else
         lx =0; ly =0; lz =0;
     end
       
end