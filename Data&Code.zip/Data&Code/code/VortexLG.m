function output= VortexLG(rho,phi, para) 
% This function is used to calculate the vortex quantities of a Laguerre-Gaussian
% beam  at z=0 plane

%In the output:
%  n is the photon number density (PND)
%  j is the PND current unit vector and jn is the norm of vector j
% v is the velocity unit vector and vn is the norm of the velocity

   if isfield(para,'alpha')
       alpha =para.alpha;
   else
       alpha =1;       
   end
       
    lambda0 = para.lambda0;% center wave length
    w0 = para.w0;% waist of the beam
    m = para.m;% index of the helical phase
    p = para.p;% index of the Laguerre function
    
    

    
    n = (abs(alpha))^2* ((sqrt(2)*rho/w0)^(abs(m)) * laguerreL(p,abs(m),2*rho^2/w0^2) *exp(-rho^2/w0^2) )^2;
    output.n = n;
                 
    
     jn = (abs(alpha))^2 ...
         *((sqrt(2)*rho/w0)^(abs(m)) * laguerreL(p,abs(m),2*rho^2/w0^2) *exp(-rho^2/w0^2) )^2 ...
         * abs(m)*lambda0/2/pi/rho;     
     j = sign(m)*jn*[-sin(phi), cos(phi), 0];         
     output.jn = jn;
     if jn >0
         output.j = j/jn;
     else
         output.j = [0,0,0];
     end
     
     if n/jn>1e-8
          v = j/n;
          vn = norm(j/n);
          output.vn = vn;
          output.v = v/vn;
     else
         output.v = [0 0 0];
         output.vn = 0;
     end
    
end