function [lx, ly, lz] = OAMtextureBessel(rho,phi,z, para) 
% This function is used to calculate the OAM texure of a Bessel pulse
% at z=0 plane
% The OAM density has been normalized by the total photon number n
    lambda = para.lambda;
%     np = para.nphoton;
    C0 = para.C0;
    sigma_r = para.sigma_r;
    sigma_z = para.sigma_z;
    theta_c = para.theta_c;
    m = para.m;
    
     lz = C0/2/pi/sigma_r^2/sigma_z  ...
               *(  (m-lambda)*(cos(theta_c/2) )^4*besselj(m-lambda,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) ...
              +(m+lambda)*(sin(theta_c/2) )^4*besselj(m+lambda,rho*sin(theta_c))*besselj(m+lambda,rho*sin(theta_c))  ... 
              +0.5*(sin(theta_c) )^2*besselj(m,rho*sin(theta_c))*besselj(m,rho*sin(theta_c)) ) * exp(-z^2/2/sigma_z^2) ;           
      
     lrho = -(C0/2/pi/sigma_r^2/sigma_z) *z/rho ...
                 *(  (m-lambda)*(cos(theta_c/2) )^4*besselj(m-lambda,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) ...
              +(m+lambda)*(sin(theta_c/2) )^4*besselj(m+lambda,rho*sin(theta_c))*besselj(m+lambda,rho*sin(theta_c))  ... 
              +0.5*(sin(theta_c) )^2*besselj(m,rho*sin(theta_c))*besselj(m,rho*sin(theta_c)) ) * exp(-z^2/2/sigma_z^2); 
          
     lphi = (C0/2/pi/sigma_r^2/sigma_z) *rho*cos(theta_c)...
                *( (m-lambda)*(cos(theta_c/2) )^4*besselj(m-lambda,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) ...
              +(m+lambda)*(sin(theta_c/2) )^4*besselj(m+lambda,rho*sin(theta_c))*besselj(m+lambda,rho*sin(theta_c))  ... 
              +0.5*(sin(theta_c) )^2*besselj(m,rho*sin(theta_c))*besselj(m,rho*sin(theta_c)) ) * exp(-z^2/2/sigma_z^2); 
          
       lx = lrho*cos(phi) - lphi * sin(phi);  
       ly = lrho*sin(phi) + lphi * cos(phi);  
      
       
end