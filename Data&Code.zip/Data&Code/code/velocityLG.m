function [vx, vy,vz,vnorm] = velocityLG(rho,phi, para) 
% This function is used to calculate the OAM texure of a Laguarre-Gaussian
% beam at z=0 plane

% The output is a unit vector [vx,vy,vz] 
% and the norm of the current vector vnorm
% The true current vector is vnorm * [vx,vy,vz]


    lambda0 = para.lambda; % center wave length
    m = para.m;

    vnorm = abs(m)*lambda0/2/pi./rho;

    vx = - sign(m)*sin(phi);  
    vy =sign(m)*cos(phi);
    vz = 0;
end