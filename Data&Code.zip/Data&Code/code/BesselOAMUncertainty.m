function DLx = BesselOAMUncertainty(para)
% This function is used to calculate the uncertainty of OAM in transverse
% plane

    np = para.nphoton; % photon number
    C0 = para.C0; % center wave number/width ratio
    theta_c = para.theta_c; % polar angle of Bessel pulse
    m = para.m;
    x = tan(theta_c);
    
    
    DLx = 0.5* np*( (C0^2+1/4)*x^2 + (C0^2+m^2+3/4)/x^2-1   );

end