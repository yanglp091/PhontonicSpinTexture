function output= VortexMixed2BG(rho,phi, para) 
% This function is used to calculate the vortex quantities of mixed two Bessel-Gaussian
% beams  at z=0 plane
%  n is the photon number density (PND)

%In the output:
%  n is the photon number density (PND)
%  j is the PND current unit vector and jn is the norm of vector j
% v is the velocity unit vector and vn is the norm of the velocity

if isfield(para,'delta')
    delta = para.delta; % relative constant phase between two beams
else
    delta =0;    
end


    lambda0 = para.lambda0;% center wave length
    alpha =para.alpha; alpha1=alpha(1); alpha2=alpha(2);
    w0 = para.w0; w01=w0(1); w02 =w0(2);
    theta_c= para.theta_c; theta_c1=theta_c(1); theta_c2=theta_c(2);
    m = para.m;  m1=m(1);  m2 = m(2);  
    p = para.p;  p1 = p(1);  p2 = p(2);
    beta1 = 2*pi*sin(theta_c1)/lambda0;
    beta2 = 2*pi*sin(theta_c2)/lambda0;
    
    n = abs( ...
                         alpha1*besselj(p1,beta1*rho)*exp(-rho^2/w01^2+1i*m1*phi)   ...
                        + alpha2*besselj(p2,beta2*rho)*exp(-rho^2/w02^2+1i*m2*phi)  ...
                     )^2;
    output.n = n;
                 
    
    
     psi1 = alpha1*besselj(p1,beta1*rho)*exp(-rho^2/w01^2);
     psi2 = alpha2*besselj(p2,beta2*rho)*exp(-rho^2/w02^2);
     j = (lambda0/2/pi/rho)*(     m1*psi1^2+m2*psi2^2 ...
         +(m1+m2)*psi1*psi2*cos((m1-m2)*phi +delta)   ) *[-sin(phi), cos(phi), 0];         
     jn = norm(j);
     output.jn = jn;
     if jn >0
         output.j = j/jn;
     else
         output.j = [0,0,0];
     end
     
     if n/jn>1e-8
          v = j/n;
          vn = norm(j/n);
          output.vn = vn;
          output.v = v/vn;
     else
         output.v = [0 0 0];
         output.vn = 0;
     end
    
end