function output= VortexBG(rho,phi, para) 
% This function is used to calculate the vortex quantities of a Bessel-Gaussian
% beam  at z=0 plane

%In the output:
%  n is the photon number density (PND)
%  j is the PND current unit vector and jn is the norm of vector j
% v is the velocity unit vector and vn is the norm of the velocity

   if isfield(para,'alpha')
       alpha =para.alpha;
   else
       alpha =1;       
   end
       
    lambda0 = para.lambda0;% center wave length
    w0 = para.w0;
    theta_c = para.theta_c;
    m = para.m;
    p = para.p;
    beta = 2*pi*sin(theta_c)/lambda0;
    

    
    n = abs(  alpha*besselj(p,beta*rho)*exp(-rho^2/w0^2+1i*m*phi)  )^2;
    output.n = n;
                 
    
     jn = (alpha*besselj(p,beta*rho)*exp(-rho^2/w0^2) )^2 * abs(m)*lambda0/2/pi/rho;     
     j = sign(m)*jn*[-sin(phi), cos(phi), 0];         
     output.jn = jn;
     if jn >0
         output.j = j/jn;
     else
         output.j = [0,0,0];
     end
     
     if n/jn>1e-8
          v = j/n;
          vn = norm(j/n);
          output.vn = vn;
          output.v = v/vn;
     else
         output.v = [0 0 0];
         output.vn = 1e8;
     end
    
end