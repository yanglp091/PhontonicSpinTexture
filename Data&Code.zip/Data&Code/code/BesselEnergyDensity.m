function denE = BesselEnergyDensity(rho,phi,z, para)
% This function is used to generator the energy density of a Bessel pulse


    lambda = para.lambda;
    np = para.nphoton;
    C0 = para.C0;
    sigma_r = para.sigma_r;
    sigma_z = para.sigma_z;
    theta_c = para.theta_c;
    m = para.m;
    
    % the energy density is symmetrical around z axis
    
    denE1 = np*(C0/2/pi/sigma_r^2/sigma_z) * (cos(theta_c/2) )^4 ...
              *besselj(m-lambda,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) ... 
              * exp(-z^2/2/sigma_z^2);  
          
    denE2 = np*(C0/2/pi/sigma_r^2/sigma_z) * (sin(theta_c/2) )^4 ...
              *besselj(m+lambda,rho*sin(theta_c))*besselj(m+lambda,rho*sin(theta_c)) ... 
              * exp(-z^2/2/sigma_z^2); 
          
    denE3 = np*0.5 * (C0/2/pi/sigma_r^2/sigma_z) * (sin(theta_c) )^2 ...
              *besselj(m,rho*sin(theta_c))*besselj(m,rho*sin(theta_c)) ... 
              * exp(-z^2/2/sigma_z^2);
          
    denE = denE1 + denE2 + denE3;
     
end