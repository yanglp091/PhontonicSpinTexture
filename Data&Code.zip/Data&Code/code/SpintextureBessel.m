function [sx, sy, sz, snorm] = SpintextureBessel(rho,phi,z, para) 
% This function is used to generator the spin texture of a Bessel pulse
% The spin density is a vector
% The output gives the norm and the normalized unit vector for the spin density 
    lambda = para.lambda;
    np = para.nphoton;
    C0 = para.C0;
    sigma_r = para.sigma_r;
    sigma_z = para.sigma_z;
    theta_c = para.theta_c;
    m = para.m;
    
     s1 = -1i*(C0/2/sqrt(2)/pi/sigma_r^2/sigma_z) * sin(theta_c)*(cos(theta_c/2) )^2 ...
              *besselj(m,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) ... 
              *exp(-1i*lambda*phi) * exp(-z^2/2/sigma_z^2);           
      s2=-1i* (C0/2/sqrt(2)/pi/sigma_r^2/sigma_z) * sin(theta_c)*(sin(theta_c/2) )^2 ...
              *besselj(m+lambda,rho*sin(theta_c))*besselj(m,rho*sin(theta_c)) ... 
              *exp(-1i*lambda*phi) * exp(-z^2/2/sigma_z^2);  
      sp = s1 +s2;
      
      
      s3 = 1i*(C0/2/sqrt(2)/pi/sigma_r^2/sigma_z) * sin(theta_c)*(sin(theta_c/2) )^2 ...
              *besselj(m+lambda,rho*sin(theta_c))*besselj(m,rho*sin(theta_c)) ... 
              *exp(1i*lambda*phi) * exp(-z^2/2/sigma_z^2);        
      s4 = 1i*(C0/2/sqrt(2)/pi/sigma_r^2/sigma_z) * sin(theta_c)*(cos(theta_c/2) )^2 ...
              *besselj(m,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) ... 
              *exp(1i*lambda*phi) * exp(-z^2/2/sigma_z^2);  
       sm=s3+s4;
       

      s5 = (lambda*C0/2/pi/sigma_r^2/sigma_z) * (cos(theta_c/2) )^4 ...
              *besselj(m-lambda,rho*sin(theta_c))*besselj(m-lambda,rho*sin(theta_c)) * exp(-z^2/2/sigma_z^2);  
      s6 = - (lambda*C0/2/pi/sigma_r^2/sigma_z) * (sin(theta_c/2) )^4 ...
              *besselj(m+lambda,rho*sin(theta_c))*besselj(m+lambda,rho*sin(theta_c)) * exp(-z^2/2/sigma_z^2);  
          
       sx = (sp+sm)/sqrt(2);  
       sy = 1i*lambda*(sp-sm)/sqrt(2);
       sz = np*(s5 + s6);
       
       snorm = norm([sx,sz,sz]);
       if snorm >0
           sx = sx/snorm;
           sy = sy/snorm;
           sz = sz/snorm;
       else
           sx = 0;
           sy = 0;
           sz = 0;
       end
       
end