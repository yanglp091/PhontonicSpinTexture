%% Energy density Vs xy
if 0
load('../output/DataEnergyDensity_lambda1_m2_C100_theta_0.2pi.mat')
fz1=48;fz2=36;lw=2; rm =10;
figure();

surf(X,Y,denE)
view([0,90])
shading interp
colormap(gray);
grid off; %axis off;

Ax = gca;   Ax.ZAxis.Visible = 'off';
xlim([-rm,rm]);  ylim([-rm,rm]);  zlim([0,2.5e-6]);
set(gca,'XTick',-10:5:10,'XTickLabel',' ','YTick',-10:5:10,'YTickLabel',' ','ZTick',[]);
set(gca,'TickLength',[0.02 0.02],'LineWidth',3.5)

h=colorbar;%'Ticks',0:5e-7:10e-7,
set(h,'location','east','position',[0.91 0.25 0.03 0.5]);
set(h,'TickLength', 0.03,'TickLabels','','color',[0.3,0,0],'LineWidth',3)

fname=['./../output/EnergyDensity' '.png'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end

%% Energy density Vs z
% if 0
load('../output/DataEnergyDensitVs_z_lambda1_m2_C100_theta_0.2pi.mat')
fz1=48;fz2=36;lw=2; rm =10;
figure();

plot(zlist,denE,'LineWidth',3.5);

Ax = gca;   Ax.ZAxis.Visible = 'off';
xlim([-500,500]);  ylim([0,2.5e-6]);  
set(gca,'XTick',-500:250:500,'XTickLabel',' ','YTick',0:0.5e-6:2.5e-6,'YTickLabel',' ');
set(gca,'TickLength',[0.02 0.02],'LineWidth',3.5)


fname=['./../output/EnergyDensityVsz' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
% end

%% Spin texture for different theta_c
 if 0
%  load('../output/Data_Fig_SpinTexture3D.mat')

fz1=48;fz2=36;lw=2;
figure();

w_p=0.4; h_p=0.45; rm =10.5;

head_frac =0.5; r_stem =0.15; r_head = 0.3;
% AC =[0.5, 0.200, 0.5]; % arrow color
AC = [0.851, 0.325, 0.098];
fname=['../output/SpinTexture' '3.png'];
% if 0
%%       theta_c =0.1 pi;  m=0

subplot('position',[0.05,0.55,w_p,h_p])

colorarray = [...                        
                      0.000, 0.447, 0.741;...
                      0.467, 0.675, 0.188;...  
                      0.871, 0.490, 0.000;...
                      0.000, 0.800, 0.600;...                      
                      0.000, 0.250, 1.000;...  
                      0.000, 0.800, 1.000;...  
                      0.200, 0.200, 1.000;...
                      ];
const =3; % for m=0;  theta_c = 0.2


surf(x1mat,y1mat,z1mat)
view([45,60]);
colormap(parula); 
caxis([0,1]*1e-6);
shading interp
h=colorbar('Ticks',0:5e-7:10e-7,'TickLabels','');
set(h,'location','north','position',[0.1 0.88 0.25 0.02]);
set(h,'TickLength',[0.03 0.03],'color',[0.5,0,0])
% set(h, 'XColor', [1 1 1],'YColor',[1,1,1])


hold on;
Ax = gca;
Ax.ZAxis.Visible = 'off'; 
xlim([-rm,rm]);  ylim([-rm,rm]);  zlim([0,8]);
set(gca,'XTick',-10:5:10,'XTickLabel',' ','YTick',-10:5:10,'YTickLabel',' ','ZTick',[]);%[0,1,2,3e-7]
set(gca,'TickLength',[0.02,0.03],'FontSize',fz2,'LineWidth',2);

row_idxList = [ 20,38,60,85,98 ];
stepList = [5,5,4,3,2,1];
for i = 1:length(row_idxList)
    ridx = row_idxList(i);
    step = stepList(i);
    XX = x1mat(ridx,:);YY = y1mat(ridx,:);ZZ = z1mat(ridx,:);UU = u1mat(ridx,:);VV=v1mat(ridx,:);WW=w1mat(ridx,:);
    x1List = XX(1:step:end)';
    y1List = YY(1:step:end)';
    z1List = ZZ(1:step:end)';
    uList = UU(1:step:end)';
    vList = VV(1:step:end)';
    wList = WW(1:step:end)';
    
    x2List = x1List + const* uList; y2List = y1List + const* vList; z2List = z1List + const* wList;
    xArray = [x1List, x2List];  yArray = [y1List, y2List];  zArray = [z1List, z2List];  
    
    
%     arrowcolor=colorarray(i,:);
    arrowcolor= AC;
    
    npoint = length(x1List);
    for  k = 1:npoint
        arrow3D(xArray(k,:), yArray(k,:), zArray(k,:),head_frac,r_stem,r_head,arrowcolor);        
        lighting phong;
        camlight head;
    end    
end
grid  'off'; hold off; clc;

%%       theta_c =02 pi;  m=0
subplot('position',[0.55, 0.55, w_p, h_p])
colorarray = [...                         
                      0.471, 0.200, 0.000;...                          
                      0.005, 0.600, 0.098;...                           
                      0.200, 0.200, 1.000;... 
                      0.153, 0.227, 0.373;...  
                      0.000, 0.200, 0.400;...                         
                      0.100, 0.400, 0.200;...
                      0.850, 0.325, 0.098;...
                      0.000, 0.300, 0.500;... 
                      ];
const =3;
surf(x2mat,y2mat,z2mat)
view([45,60]);
colormap(parula); 
caxis([0,3]*1e-6);
shading interp
h=colorbar('Ticks',0:1e-6:3e-6,'TickLabels','');
set(h,'location','north','position',[0.6 0.88 0.25 0.02]);
set(h,'TickLength',[0.03 0.03],'color',[0.5,0,0])
hold on

% corrdinate of the arrow head
row_idxList = [ 18, 42,55,75,90];
stepList = [5,5,4,3,2];
for i = 1:length(row_idxList)
    ridx = row_idxList(i);
    step = stepList(i);
    XX = x2mat(ridx,:);YY = y2mat(ridx,:);ZZ = z2mat(ridx,:);UU = u2mat(ridx,:);VV=v2mat(ridx,:);WW=w2mat(ridx,:);
    x1List = XX(1:step:end)';
    y1List = YY(1:step:end)';
    z1List = ZZ(1:step:end)';
    uList = UU(1:step:end)';
    vList = VV(1:step:end)';
    wList = WW(1:step:end)';
    
    x2List = x1List + const* uList; y2List = y1List + const* vList; z2List = z1List + const* wList;
    xArray = [x1List, x2List];  yArray = [y1List, y2List];  zArray = [z1List, z2List];  
    
    
%     arrowcolor=colorarray(i,:);
    arrowcolor= AC;
    npoint = length(x1List);
    for  k = 1:npoint
        arrow3D(xArray(k,:), yArray(k,:), zArray(k,:),head_frac,r_stem,r_head,arrowcolor);        
        lighting phong;
        camlight head;
    end    
end
hold off;     grid  'off'; clc;

Ax = gca;   Ax.ZAxis.Visible = 'off';
xlim([-rm,rm]);  ylim([-rm,rm]);  zlim([0,8]);

set(gca,'XTick',-10:5:10,'XTickLabel',' ','YTick',-10:5:10,'YTickLabel',' ','ZTick',[]);%[0,1,2,3e-7]
set(gca,'TickLength',[0.02,0.03],'FontSize',fz2,'LineWidth',2);


%%  theta_c =0.2 pi;  m=1
subplot('position',[0.05,0.05,w_p,h_p])
colorarray = [...                        
                      0.800, 0.5, 0.198;...                      
                      0.000, 0.600, 0.400;... 
%                       0.005, 0.300, 1.000;...                         
                      0.200, 0.400, 1.000;... 
                      0.000, 0.498, 0.800;...
                      0.200, 0.400, 1.000;... 
                      0.000, 0.447, 0.741;...
                      0.451, 0.263, 0.263;...                      
                      0.757, 0.867, 0.776;...                                       
                      ];

const = 3;       

surf(x3mat,y3mat,z3mat)
view([45,54]);
colormap default; 
caxis([0,8]*1e-6);
shading interp
h=colorbar('Ticks',0:4e-6:8e-6,'TickLabels','');
set(h,'location','north','position',[0.1 0.365 0.25 0.02]);
set(h,'TickLength',[0.03 0.03],'color',[0.5,0,0])

hold on

Ax = gca;   Ax.ZAxis.Visible = 'off';
xlim([-rm,rm]);  ylim([-rm,rm]);  zlim([0,13]);
set(gca,'XTick',-10:5:10,'XTickLabel',' ','YTick',-10:5:10,'YTickLabel',' ','ZTick',[]);%[0,1,2,3e-7]
set(gca,'TickLength',[0.02,0.03],'FontSize',fz2,'LineWidth',2);

% corrdinate of the arrow head
row_idxList = [1, 25,50,65,80,93];
stepList = [100,7,5,5,3,3];
ini_List=[2,3,2,2,1,1];
for i = 1:length(row_idxList)
    ridx = row_idxList(i);
    step = stepList(i);
     ini = ini_List(i);
    XX = x3mat(ridx,:);YY = y3mat(ridx,:);ZZ = z3mat(ridx,:);UU = u3mat(ridx,:);VV=v3mat(ridx,:);WW=w3mat(ridx,:);
    x1List = XX(ini:step:end)';
    y1List = YY(ini:step:end)';
    z1List = ZZ(ini:step:end)';
    uList = UU(ini:step:end)';
    vList = VV(ini:step:end)';
    wList = WW(ini:step:end)';
    
    x2List = x1List + const* uList; y2List = y1List + const* vList; z2List = z1List + const* wList;
    xArray = [x1List, x2List];  yArray = [y1List, y2List];  zArray = [z1List, z2List];  
    
    
%     arrowcolor=colorarray(i,:);
    arrowcolor= AC;
    npoint = length(x1List);
    for  k = 1:npoint
        arrow3D(xArray(k,:), yArray(k,:), zArray(k,:),head_frac,r_stem,r_head,arrowcolor);                
        lighting phong;
        camlight head;
%         camlight(10,0);  
    end 
            
end
hold off;     grid  'off'; clc;

% if 0
%%   theta_c =02 pi;  m=2
subplot('position',[0.55,0.05,w_p,h_p])

colorarray = [...                        
                      0.000, 0.100, 1.000;...  
                      0.850, 0.325, 0.098;...
%                       0.571, 0.250, 0.000;...                          
                      0.165, 0.384, 0.275;...                           
                      0.200, 0.200, 1.000;... 
                      0.153, 0.227, 0.373;...                     
                      0.514, 0.380, 0.482;... 
                      0.000, 0.400, 0.400;...                                                                     
                      ];

const = 3;       
surf(x4mat,y4mat,z4mat)
view([45,60]);
colormap(parula); 
caxis([0,3]*1e-6);
shading interp
h=colorbar('Ticks',0:1e-6:3e-6,'TickLabels','');
set(h,'location','north','position',[0.6 0.375 0.25 0.02]);
set(h,'TickLength',[0.03 0.03],'color',[0.5,0,0])

hold on

row_idxList = [ 8, 32,50,67,96];
stepList = [10,7,4,3,2];
ini_List=[2,3,2,2,1,1];

for i = 1:length(row_idxList)
ridx = row_idxList(i);
    step = stepList(i);
    ini = ini_List(i);
    XX = x4mat(ridx,:);YY = y4mat(ridx,:);ZZ = z4mat(ridx,:);UU = u4mat(ridx,:);VV=v4mat(ridx,:);WW=w4mat(ridx,:);
    x1List = XX(ini:step:end)';
    y1List = YY(ini:step:end)';
    z1List = ZZ(ini:step:end)';
    uList = UU(ini:step:end)';
    vList = VV(ini:step:end)';
    wList = WW(ini:step:end)';
    
    x2List = x1List + const* uList; y2List = y1List + const* vList; z2List = z1List + const* wList;
    xArray = [x1List, x2List];  yArray = [y1List, y2List];  zArray = [z1List, z2List];  
    
    
%     arrowcolor=colorarray(i,:);
    arrowcolor= AC;
    npoint = length(x1List);
    for  k = 1:npoint
        arrow3D(xArray(k,:), yArray(k,:), zArray(k,:),head_frac,r_stem,r_head,arrowcolor);                
        lighting phong;
        camlight head;
    end    
end
hold off;     grid  'off'; clc;

Ax = gca;   Ax.ZAxis.Visible = 'off';
xlim([-rm,rm]);  ylim([-rm,rm]);  zlim([0,6]);
set(gca,'XTick',-10:5:10,'XTickLabel',' ','YTick',-10:5:10,'YTickLabel',' ','ZTick',0:4:10);%[0,1,2,3e-7]
set(gca,'TickLength',[0.02,0.03],'FontSize',fz2,'LineWidth',2);


set(gcf,'PaperSize',[21 16],'PaperPosition',[0.5, 0.5, 20, 15]);
saveas(gcf, fname);

end

%% Spintexture Vs rho for different theta_c

if 0
    
load('../output/Data_Spin_xyProjection_Diff_theta_c.mat')

figure()
xlim([0,10]);  ylim([-0.5,4.5]);  zlim([0,8])
set(gca,'XTick',0:2:10,'XTickLabel',' ','YTick',0:2:12,'YTickLabel',' ','ZTick',0:4:8,'ZTickLabel',' ');%[0,1,2,3e-7]
view([0,90]);
hold on


quiver3(x1,y1,z1,u1,v1,w1,0,'LineWidth',2,'MaxHeadSize',0.1) 
quiver3(x2,y2+2,z2,u2,v2,w2,0,'LineWidth',2,'MaxHeadSize',0.1) 
quiver3(x3,y3+4,z3,u3,v3,w3,0,'LineWidth',2,'MaxHeadSize',0.1) 

hold off

set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',2)

fname=['./../output/SpinProject_xy_Diff_theta_c' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end

%% Spin texture Vs rho for different varphi
if 0
% clear;clc;
% fname='lambda1_m0_C100_theta_0.2pi_1';
% load(['../output/BesselSpin/Data_' fname '.mat']);



lw=4;
figure()

const = 1.5e6;
xlim([-10.1,10.1]);  ylim([-10.1,10.1]);  zlim([0,1])
set(gca,'XTick',-10:5:10,'XTickLabel',' ','YTick',-10:5:10,'YTickLabel',' ','ZTick','');%[0,1,2,3e-7]
view([45,80]);

step = 2;
hold on

for  j = 1:4:24
    x = X(1:step:end,j);
    y = Y(1:step:end,j);
    z = zeros(length(x),1);    
    quiver3(x,y,z,real(const*U(1:step:end,j)),real(const*V(1:step:end,j)),z,0,'LineWidth',2,'MaxHeadSize',0.08)    %real(const*W(:,j))    
end
hold off;

set(gca,'box','off','TickLength',[0.02,0.02],'LineWidth',2);
Ax = gca;Ax.ZAxis.Visible = 'off';%Ax.ZGrid = 'off';Ax.Color = 'none';

fname=['./../output/SpinProject_xy' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end


%% Spintexture Vs rho for different m

if 0
    
% load('../output/Data_Fig_SpinTexture-xy-diff-m.mat')
const=1e6;

figure()
xlim([0,10]);  ylim([-2,6]);  zlim([0,8])
set(gca,'XTick',0:2:10,'XTickLabel',' ','YTick',0:2:12,'YTickLabel',' ','ZTick',0:4:8,'ZTickLabel',' ');%[0,1,2,3e-7]
view([0,90]);
hold on


quiver3(x2,y2,     z2,const*u2,const*v2,const*w2,0,'LineWidth',2,'MaxHeadSize',0.1) 
quiver3(x3,y3+2,z3,const*u3,const*v3,const*w3,0,'LineWidth',2,'MaxHeadSize',0.1) 
quiver3(x4,y4+4,z4,const*u4,const*v4,const*w4,0,'LineWidth',2,'MaxHeadSize',0.1) 

hold off

set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',2)

fname=['./../output/SpinProject_xy_Diff_m' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end

%% Spintexture in z-axis Vs rho for different m

if 0
    
% load('../output/Data_Fig_SpinTexture-xy-diff-m.mat')
lw=6;

figure()
xlim([0,10]);  ylim([-0.5e-6,7e-6]); 
line(rholist,w1,'LineStyle','-','Color',[0,0.0,0],'LineWidth',lw);
line(rholist,w2,'LineStyle','--','Color',[1,0.1,0],'LineWidth',lw);
line(rholist,w3,'LineStyle','-.','Color',[0,0.5,0],'LineWidth',lw);
line(rholist,w4,'LineStyle',':','Color',[0,0.1,0.8],'LineWidth',lw);
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',2);
set(gca,'XTick',0:2:10,'XTickLabel',' ','YTick',0:1e-6:7e-6,'YTickLabel',' ');%[0,1,2,3e-7]

% h = legend(' ',' ',' ',' ');
% set(h,'position',[0.4,0.2,0.2,0.8]);
% set(h,'box','off');

fname=['./../output/SpinProject_z_Diff_m' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end


%%  OAM uncertainties in transverse plane
if 0
    
w_p=0.4; h_p=0.35; rm =10.5;
fz1=48;fz2=36;lw=3; mz =10;

figure()

% subplot('position',[0.05,0.55,w_p,h_p])

subplot('position',[0.55, 0.55, w_p, h_p])

load('./../output/Data_OAM_UncertaityVs_nphoton_diff_m.mat');

xlim([0,10]);  ylim([0,1e6]); 
line(nlist,DLmat(1,:),'LineStyle','-','Color',[0,0.0,0],'LineWidth',lw,'Marker','o','MarkerSize',mz);
line(nlist,DLmat(2,:),'LineStyle','-','Color',[1,0.1,0],'LineWidth',lw,'Marker','*','MarkerSize',mz);
line(nlist,DLmat(3,:),'LineStyle','-','Color',[0,0.5,0],'LineWidth',lw,'Marker','<','MarkerSize',mz);
line(nlist,DLmat(4,:),'LineStyle','-','Color',[0,0.1,0.8],'LineWidth',lw,'Marker','d','MarkerSize',mz);
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',lw);
set(gca,'XTick',0:2:10,'YTick',0:2e5:1e6,'FontSize',fz2);%,'XTickLabel',' ','YTickLabel',' '

h = legend(' ',' ',' ',' ');
set(h,'position',[0.56,0.58,0.1,0.3]);
set(h,'box','off');


lw=4;
subplot('position',[0.05,0.05,w_p,h_p])
load('./../output/Data_OAM_UncertaityVs_m_diff_nphoton.mat');

xlim([0,200]);  ylim([0,2.4e6]); 
line(mlist,DLmat(1,:),'LineStyle','-','Color',[0,0.0,0],'LineWidth',lw);%,'Marker','o','MarkerSize',mz
line(mlist,DLmat(2,:),'LineStyle','--','Color',[1,0.1,0],'LineWidth',lw);%,'Marker','*','MarkerSize',mz
line(mlist,DLmat(3,:),'LineStyle','-.','Color',[0,0.5,0],'LineWidth',lw);%,'Marker','<','MarkerSize',mz
line(mlist,DLmat(4,:),'LineStyle',':','Color',[0,0.1,0.8],'LineWidth',lw);%,'Marker','d','MarkerSize',mz
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',lw);
set(gca,'XTick',0:50:200,'YTick',0:1e6:3e6,'FontSize',fz2);%'XTickLabel',' ','YTickLabel',' '
% set(gca,'XScale','log')%,'YScale','log'

h = legend(' ',' ',' ',' ');
set(h,'position',[0.08,0.07,0.05,0.3]);
set(h,'box','off');



subplot('position',[0.55,0.05,w_p,h_p])
load('../output/Data_OAM_UncertaityVs_thetac_diff_m_nphoton.mat');

xlim([0.1,0.4]);  ylim([0,1e5]); 
line(thetalist,DLmat(1,:),'LineStyle','-','Color',[0,0.0,0],'LineWidth',lw);%,'Marker','o','MarkerSize',mz
line(thetalist,DLmat(2,:),'LineStyle','--','Color',[1,0.1,0],'LineWidth',lw);%,'Marker','*','MarkerSize',mz
line(thetalist,DLmat(3,:),'LineStyle','-.','Color',[0,0.5,0],'LineWidth',lw);%,'Marker','<','MarkerSize',mz
line(thetalist,DLmat(4,:),'LineStyle',':','Color',[0,0.1,0.8],'LineWidth',lw);%,'Marker','d','MarkerSize',mz
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',lw);
set(gca,'XTick',0:0.1:0.4,'YTick',0:2e4:3e6,'FontSize',fz2);%,'XTickLabel',[0.1,0.2,0.3,0.4],'YTickLabel',' '

h = legend(' ',' ',' ',' ');
set(h,'position',[0.68,0.1,0.05,0.3]);
set(h,'box','off');

fname=['./../output/OAMuncertainty' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end


%%  Spin density correlation
if 0
 
load('./../output/Data_SpinDensityCorrelationVs_r_diff_nphoton.mat');
w_p=0.4; h_p=0.35; rm =10.5;
fz1=48;fz2=36;lw=5; mz =10;

figure()

% subplot('position',[0.05,0.55,w_p,h_p])

subplot('position',[0.55, 0.55, w_p, h_p])
xlim([0,20]);  ylim([-1e-11,4e-11]); 
line(rlist,FSmat(1,:),'LineStyle','-','Color',[0.75, 0., 0.75],'LineWidth',lw);%,'Marker','o','MarkerSize',mz
line(rlist,CSmat(1,:),'LineStyle','-.','Color',[0,0.447,0.741],'LineWidth',lw);%,'Marker','*','MarkerSize',mz
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',lw);
set(gca,'XTick',0:5:20,'YTick',-1e-11:1e-11:1e-10,'FontSize',fz2);%,'XTickLabel',' ','YTickLabel',' '

h = legend(' ',' ');
set(h,'position',[0.65,0.6,0.1,0.3]);
set(h,'box','off');


subplot('position',[0.05,0.05,w_p,h_p])
xlim([0,20]);  ylim([0,1.5e-10]); 
line(rlist,FSmat(2,:),'LineStyle','-','Color',[0.75, 0., 0.75],'LineWidth',lw);%,'Marker','o','MarkerSize',mz
line(rlist,CSmat(2,:),'LineStyle','-.','Color',[0,0.447,0.741],'LineWidth',lw);%,'Marker','*','MarkerSize',mz
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',lw);
set(gca,'XTick',0:5:20,'YTick',0:5e-11:1.5e-10,'FontSize',fz2);%,'XTickLabel',' ','YTickLabel',' '

h = legend(' ',' ');
set(h,'position',[0.18,0.1,0.05,0.3]);
set(h,'box','off');



subplot('position',[0.55,0.05,w_p,h_p])
xlim([0,20]);  ylim([0,9e-10]); 
line(rlist,FSmat(3,:),'LineStyle','-','Color',[0.75, 0., 0.75],'LineWidth',lw);%,'Marker','o','MarkerSize',mz
line(rlist,CSmat(3,:),'LineStyle','-.','Color',[0,0.447,0.741],'LineWidth',lw);%,'Marker','*','MarkerSize',mz
set(gca,'box','on','TickLength',[0.02,0.02],'LineWidth',lw);
set(gca,'XTick',0:5:20,'YTick',0:2e-10:8e-10,'FontSize',fz2);%,'XTickLabel',' ','YTickLabel',' '


h = legend(' ',' ');
set(h,'position',[0.67,0.1,0.05,0.3]);
set(h,'box','off');

fname=['./../output/SpinDensityCorrelation' '.pdf'];
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.6, 0.6, 20, 15]);
saveas(gcf, fname);
end