%% spin density matrix in xy-plane
if 0
clear;clc;
theta_str = '0.2';
nphoton =1; para.nphoton=nphoton; % photon number
lambda = 1;  para.lambda=lambda; %circular polarization
kz0 = 1;  para.kz0 = kz0; %center wave vector z
theta_c = pi*str2double(theta_str); para.theta_c=theta_c; % uniform polar angle pi/3; pi/20
rho_k0 = kz0*tan(theta_c); % projection of k in xy-plane
C0 = 100; para.C0 = C0; % ratio of k and its width Delta_k
sigma_r = C0/rho_k0; para.sigma_r = sigma_r; % sigma_rho
sigma_z = C0;  para.sigma_z = sigma_z; % simga_z=c*tau_p 
m = 2; para.m = m; % orbital angular momentum index
z=0;

if strcmp(theta_str,'0.05')   
    rholist=0:0.2:20; nphi=51;
elseif strcmp(theta_str,'0.1')
    rholist=0:0.1:15; nphi=51;
elseif strcmp(theta_str,'0.2')
    rholist=[0:0.2:1, 1.1:0.1:10];    nphi=51;
elseif  strcmp(theta_str,'0.3')
     rholist=[0:0.2:2,2.4:0.1:8, 8.2:0.05:10];  nphi=51;    
else
    error('The setting of theta_c is wrong!')    
end
nrho=length(rholist);
philist=linspace(0,2*pi,nphi);

denE = zeros(nrho,nphi);

for j=1:nrho
        rho=rholist(j);
        for k=1:nphi
            phi=philist(k);
            denE(j,k) = BesselEnergyDensity(rho,phi,z, para);
            
        end
end

[phi,rho]=meshgrid(philist,rholist);
[X,Y] = pol2cart(phi, rho);

save(['../output/DataEnergyDensity_lambda' num2str(lambda) '_m' num2str(m) '_C' num2str(C0)...
    '_theta_' theta_str 'pi.mat'],'para','rholist','X','Y','denE');

surf(X,Y,denE)
view([0,90])
shading interp
end


%% spin density on z-axis
% if 0
clear;clc;
theta_str = '0.2';
nphoton =1; para.nphoton=nphoton; % photon number
lambda = 1;  para.lambda=lambda; %circular polarization
kz0 = 1;  para.kz0 = kz0; %center wave vector z
theta_c = pi*str2double(theta_str); para.theta_c=theta_c; % uniform polar angle pi/3; pi/20
rho_k0 = kz0*tan(theta_c); % projection of k in xy-plane
C0 = 100; para.C0 = C0; % ratio of k and its width Delta_k
sigma_r = C0/rho_k0; para.sigma_r = sigma_r; % sigma_rho
sigma_z = C0;  para.sigma_z = sigma_z; % simga_z=c*tau_p 
m = 2; para.m = m; % orbital angular momentum index
zlist=-500:0.1:500;


nz=length(zlist);
rho =3.3;phi = 0;

denE = zeros(1,nz);

for j=1:nz

    z=zlist(j);
    denE(j) = BesselEnergyDensity(rho,phi,z, para);
end

plot(zlist,denE)

save(['../output/DataEnergyDensitVs_z_lambda' num2str(lambda) '_m' num2str(m) '_C' num2str(C0)...
    '_theta_' theta_str 'pi.mat'],'para','zlist','rho','denE');

% end