function  [FS, CS] = BesselSpinDensityZZcorelation(rho, para)
% This function is used to calculate the spin density correlation for the
% special case m=1 and lambda = +1
% one detector (NV center ) is placed on z-axis
% the other detector is moving in radial direction 
% rho is the distance between the two detectors


    lambda = 1;
    np = para.nphoton;
    C0 = para.C0;
    sigma_r = para.sigma_r;
    sigma_z = para.sigma_z;
    theta_c = para.theta_c;
    m = 1;
    
    FS  = np*(np-1)*(C0/2/sqrt(2)/pi/sigma_r^2/sigma_z)^2*(besselj(m-lambda,0) )^2 * (besselj(m-lambda,rho*sin(theta_c)) )^2;
    CS  = np^2*(C0/2/sqrt(2)/pi/sigma_r^2/sigma_z)^2*(besselj(m-lambda,0) )^2 * (besselj(m-lambda,rho*sin(theta_c)) )^2;

end